var navs = [{
		"title": "按钮",
		"icon": "&#xe641;",
		"href": "button"
	}, {
		"title": "表单",
		"icon": "&#xe63c;",
		"href": "form"
	}, {
		"title": "表格",
		"icon": "&#xe63c;",
		"href": "table"
	}, {
		"title": "导航",
		"icon": "&#xe609;",
		"href": "nav"
	}, {
		"title": "辅助性元素",
		"icon": "&#xe60c;",
		"href": "auxiliar"
}];